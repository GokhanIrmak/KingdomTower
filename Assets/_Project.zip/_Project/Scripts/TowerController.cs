using UnityEngine;
using TMPro;

namespace KingdomTower
{
    /// <summary>
    /// Controls an individual tower's behavior including unit generation,
    /// health management, team ownership, and visual representation.
    /// </summary>
    [RequireComponent(typeof(MeshRenderer))]
    public class TowerController : MonoBehaviour
    {
        [Header("Configuration")]
        [SerializeField] private TowerStatsSO stats;
        [SerializeField] private Team startingTeam = Team.Neutral;

        [Header("Unit Prefab")]
        [SerializeField] private GameObject unitPrefab;

        [Header("Visual Settings")]
        [SerializeField] private Color neutralColor = Color.gray;
        [SerializeField] private Color blueTeamColor = Color.blue;
        [SerializeField] private Color redTeamColor = Color.red;

        [Header("HP Display")]
        [SerializeField] private TextMeshPro hpText;
        [SerializeField] private Vector3 hpTextOffset = new Vector3(0, 2.5f, 0);

        [Header("HP Limits")]
        [SerializeField] private int maxHP = 30;

        // Current state
        private Team currentTeam;
        private int currentUnits;
        private int currentHealth;
        private float unitGenerationTimer;
        private MeshRenderer meshRenderer;

        // Properties
        public Team CurrentTeam => currentTeam;
        public int CurrentUnits => currentUnits;
        public int CurrentHealth => currentHealth;
        public bool CanSendUnits => currentTeam != Team.Neutral; // Always can send if not neutral

        #region Unity Lifecycle

        private void Awake()
        {
            meshRenderer = GetComponent<MeshRenderer>();
            ValidateConfiguration();
        }

        private void Start()
        {
            Initialize();
        }

        private void Update()
        {
            if (currentTeam != Team.Neutral)
            {
                GenerateUnits();
            }
        }

        #endregion

        #region Initialization

        private void Initialize()
        {
            currentTeam = startingTeam;
            currentUnits = stats.StartingUnits;
            currentHealth = stats.StartingHealth;
            unitGenerationTimer = 0f;

            CreateHPText();
            UpdateVisuals();
            UpdateHPDisplay();
        }

        private void CreateHPText()
        {
            if (hpText != null) return;

            // Create HP text dynamically if not assigned
            GameObject textObj = new GameObject("HPText");
            textObj.transform.SetParent(transform);
            textObj.transform.localPosition = hpTextOffset;

            hpText = textObj.AddComponent<TextMeshPro>();
            hpText.alignment = TextAlignmentOptions.Center;
            hpText.fontSize = 8;
            hpText.fontStyle = FontStyles.Bold;

            // Make text always face camera
            textObj.AddComponent<LookAtCamera>();
        }

        private void ValidateConfiguration()
        {
            if (stats == null)
            {
                Debug.LogError($"TowerController on {gameObject.name} is missing TowerStatsSO reference!", this);
            }

            if (unitPrefab == null)
            {
                Debug.LogWarning($"TowerController on {gameObject.name} is missing unit prefab reference!", this);
            }
        }

        #endregion

        #region Unit Generation

        private void GenerateUnits()
        {
            if (currentUnits >= stats.MaxUnits)
            {
                return; // Already at max capacity
            }

            unitGenerationTimer += Time.deltaTime;

            // Check if enough time has passed to generate a unit
            float timePerUnit = 1f / stats.UnitsPerSecond;

            while (unitGenerationTimer >= timePerUnit && currentUnits < stats.MaxUnits)
            {
                currentUnits++;
                unitGenerationTimer -= timePerUnit;
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Adds units to this tower (used when capturing or reinforcing).
        /// </summary>
        public void AddUnits(int amount)
        {
            currentUnits = Mathf.Min(currentUnits + amount, stats.MaxUnits);
            currentHealth = Mathf.Min(currentHealth + amount, stats.MaxUnits);
        }

        /// <summary>
        /// Applies damage to the tower from an attacking team.
        /// If health reaches zero, ownership changes to the attacker.
        /// </summary>
        public void TakeDamage(int amount, Team attackerTeam)
        {
            if (attackerTeam == Team.Neutral)
            {
                Debug.LogWarning("Neutral team cannot attack towers!");
                return;
            }

            // If same team, add HP (up to max)
            if (attackerTeam == currentTeam)
            {
                currentHealth = Mathf.Min(currentHealth + amount, maxHP);
                UpdateHPDisplay();
                return;
            }

            currentHealth -= amount;

            // Check if tower should change ownership
            if (currentHealth <= 0)
            {
                ChangeOwnership(attackerTeam);
            }

            UpdateVisuals();
            UpdateHPDisplay();
        }

        private void UpdateHPDisplay()
        {
            if (hpText == null) return;

            hpText.text = currentHealth.ToString();

            // Color based on team
            hpText.color = currentTeam switch
            {
                Team.BlueTeam => blueTeamColor,
                Team.RedTeam => redTeamColor,
                Team.Neutral => neutralColor,
                _ => Color.white
            };
        }

        /// <summary>
        /// Sends units from this tower to attack a target tower.
        /// Called by the InputManager when drag-and-drop is completed.
        /// </summary>
        public void SendUnitsToTower(TowerController targetTower)
        {
            if (!CanSendUnits)
            {
                Debug.LogWarning($"Tower {gameObject.name} cannot send units!");
                return;
            }

            if (targetTower == null || targetTower == this)
            {
                Debug.LogWarning("Invalid target tower!");
                return;
            }

            // Calculate how many units to send
            int unitsToSend = Mathf.FloorToInt(currentUnits * stats.UnitSendPercentage);
            unitsToSend = Mathf.Max(1, unitsToSend); // Send at least 1 unit

            if (unitsToSend > currentUnits)
            {
                unitsToSend = currentUnits;
            }

            // Deduct units from this tower
            currentUnits -= unitsToSend;

            // Spawn the units and send them to the target
            SpawnUnits(unitsToSend, targetTower);
        }

        /// <summary>
        /// Sends a single unit to target tower. Used by TowerConnection for continuous flow.
        /// Units are unlimited - HP only changes when unit arrives at target.
        /// </summary>
        public void SendSingleUnit(TowerController targetTower)
        {
            if (targetTower == null || targetTower == this)
                return;

            // Units are unlimited - just spawn and send
            // HP only changes when unit arrives at destination (TakeDamage)
            SpawnUnits(1, targetTower);
        }

        #endregion

        #region Unit Spawning

        private void SpawnUnits(int count, TowerController targetTower)
        {
            if (unitPrefab == null)
            {
                Debug.LogError($"Cannot spawn units: unitPrefab is not assigned on {gameObject.name}!");
                return;
            }

            for (int i = 0; i < count; i++)
            {
                // Spawn with slight offset to prevent units stacking
                Vector3 randomOffset = new Vector3(
                    Random.Range(-0.5f, 0.5f),
                    0f,
                    Random.Range(-0.5f, 0.5f)
                );

                Vector3 spawnPosition = transform.position + randomOffset + Vector3.up * 0.5f;
                GameObject unitObj = Instantiate(unitPrefab, spawnPosition, Quaternion.identity);

                // Initialize the unit
                UnitController unit = unitObj.GetComponent<UnitController>();
                if (unit != null)
                {
                    unit.Initialize(targetTower, currentTeam);
                }
                else
                {
                    Debug.LogError($"Unit prefab is missing UnitController component!");
                    Destroy(unitObj);
                }
            }
        }

        #endregion

        #region Ownership & Visuals

        private void ChangeOwnership(Team newTeam)
        {
            currentTeam = newTeam;

            // Reset health to a small positive value when captured
            currentHealth = Mathf.Abs(currentHealth);
            if (currentHealth == 0)
            {
                currentHealth = 1;
            }

            currentUnits = currentHealth;

            UpdateVisuals();

            Debug.Log($"{gameObject.name} captured by {newTeam}!");
        }

        private void UpdateVisuals()
        {
            if (meshRenderer == null) return;

            Color targetColor = currentTeam switch
            {
                Team.Neutral => neutralColor,
                Team.BlueTeam => blueTeamColor,
                Team.RedTeam => redTeamColor,
                _ => Color.white
            };

            // Create a new material instance to avoid affecting the shared material
            if (meshRenderer.material != null)
            {
                meshRenderer.material.color = targetColor;
            }
        }

        #endregion

        #region Debug Visualization

        private void OnDrawGizmosSelected()
        {
            // Draw a sphere showing the tower's range (optional for future features)
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, 1f);
        }

        #endregion
    }
}
